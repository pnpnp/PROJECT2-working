package com.lti.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lti.model.Customer;

@Service
public interface IAdminService {
	
	
	
	public List<Customer> custlist();
	
	//public void acceptCust(int customerId);
	
	public void rejectCust(int customerId);

	public List<Customer> fetchCustomerDetails(int customerId);
	
	public void acceptCust(int customerId, double loanAmount);
	
	
}
